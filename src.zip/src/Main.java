import Choice.Choice;
public class Main {
    public static void main(String[] args) {

        Choice choice = new Choice();
        choice.choose();
    }
}
